package com.controlz.goperta;

public interface TambahKurang
{
    void tambah(int nilai);
    void kurangi(int nilai);
}